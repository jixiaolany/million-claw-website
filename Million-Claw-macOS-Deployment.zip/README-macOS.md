# Million Claw macOS 部署指南

## 🚀 快速开始

### 系统要求
- macOS 10.15 (Catalina) 或更高
- 4GB RAM 或更高
- 2GB 可用磁盘空间
- 管理员权限

### 安装步骤

1. **下载部署包**
   下载 `Million-Claw-macOS-Deployment.zip` 并解压

2. **运行安装程序**
   打开终端，进入解压目录
   运行: `sudo bash Million-Claw-macOS-Installer.sh`

3. **完成安装**
   按照提示完成安装过程

4. **启动应用**
   在应用程序中点击"Million Claw"
   或通过终端运行

### 📋 功能特性

#### 核心功能
- ✅ 原生macOS体验
- ✅ 零配置AI助手
- ✅ 本地数据安全
- ✅ 自动化工作流

#### 技术特性
- 基于OpenClaw框架
- Node.js后端
- 现代化前端界面
- SQLite本地数据库

### 🔐 安全与隐私

#### 数据安全
- 所有数据保存在本地
- 无需上传到云端
- 端到端加密
- 隐私合规设计

#### 权限控制
- 需要sudo权限安装
- 沙盒运行环境
- Gatekeeper兼容

### 💰 付费模式

#### 使用要求
1. **邀请码** (由管理员发放)
2. **付费订阅** (专业版¥199/月)

#### 付费功能
- 无限制AI功能
- 高级自动化
- 优先技术支持
- 团队协作工具

### 🆘 技术支持

#### 常见问题
**Q: 安装时提示权限被拒绝**
A: 请使用sudo运行安装脚本

**Q: 启动时提示"无法打开，因为无法验证开发者"**
A: 前往 系统偏好设置 -> 安全性与隐私 -> 通用，点击"仍要打开"

**Q: 如何获取邀请码？**
A: 联系管理员或选择付费版本

**Q: 如何卸载？**
A: 运行: `sudo uninstall-millionclaw`

#### 联系方式
- 官方网站: https://jixiaolany.github.io/your-app-website-githubpages/
- 技术支持: support@millionclaw.com
- 商务合作: sales@millionclaw.com

### 📄 许可证

Million Claw 基于 OpenClaw 框架构建，遵循相应的开源协议。

### ⚖️ 法律声明

使用 Million Claw 即表示您同意我们的服务条款和隐私政策。

---

© 2026 Million Claw Team. 保留所有权利。
